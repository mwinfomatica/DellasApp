package com.souzas.posprinterflutter.posprinter_flutter_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
